/**
 *
 * students: please put your implementation in this file!
 */
package edu.gatech.cse6250.jaccard

import edu.gatech.cse6250.model._
import edu.gatech.cse6250.model.{ EdgeProperty, VertexProperty }
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD

object Jaccard {

  def jaccardSimilarityOneVsAll(graph: Graph[VertexProperty, EdgeProperty], patientID: Long): List[Long] = {
    /**
     * Given a patient ID, compute the Jaccard similarity w.r.t. to all other patients.
     * Return a List of top 10 patient IDs ordered by the highest to the lowest similarity.
     * For ties, random order is okay. The given patientID should be excluded from the result.
     */

    /** Remove this placeholder and implement your code */
    val targetNeighbors = graph.collectNeighborIds(EdgeDirection.Out).lookup(patientID)(0)
    val targetNeighborsSet = targetNeighbors.toSet
    val patientVertices = graph.vertices.filter(vertex => vertex._2.isInstanceOf[PatientProperty] && vertex._1 != patientID)
    val allNeighbors = graph.collectNeighborIds(EdgeDirection.Out).join(patientVertices)

    allNeighbors
      .map(n => (jaccard(n._2._1.toSet, targetNeighborsSet), n._1))
      .sortByKey(false)
      .take(10)
      .map(v => v._2).toList
  }

  def jaccardSimilarityAllPatients(graph: Graph[VertexProperty, EdgeProperty]): RDD[(Long, Long, Double)] = {
    /**
     * Given a patient, med, diag, lab graph, calculate pairwise similarity between all
     * patients. Return a RDD of (patient-1-id, patient-2-id, similarity) where
     * patient-1-id < patient-2-id to avoid duplications
     */

    /** Remove this placeholder and implement your code */
    val patientIDsRdd = graph.vertices.filter(v => v._2.isInstanceOf[PatientProperty]).map(_._1)

    val patientIdToNeighborIdsMap = graph.collectNeighborIds(EdgeDirection.Out).map(t => (t._1, t._2.toSet)).collect.toMap

    val combinations = patientIDsRdd.cartesian(patientIDsRdd).filter { case (a, b) => a < b }

    combinations
      .map(t => (t._1, t._2, jaccard(patientIdToNeighborIdsMap(t._1), patientIdToNeighborIdsMap(t._2))))
  }

  def jaccard[A](a: Set[A], b: Set[A]): Double = {
    /**
     * Helper function
     *
     * Given two sets, compute its Jaccard similarity and return its result.
     * If the union part is zero, then return 0.
     */

    /** Remove this placeholder and implement your code */
    val unionCount = a.union(b).size.toDouble
    val intersectionCount = a.intersect(b).size.toDouble

    if (unionCount == 0) 0 else intersectionCount / unionCount
  }
}
