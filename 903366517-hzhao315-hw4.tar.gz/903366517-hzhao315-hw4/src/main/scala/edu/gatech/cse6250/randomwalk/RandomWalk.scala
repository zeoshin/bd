package edu.gatech.cse6250.randomwalk

import edu.gatech.cse6250.model.{ PatientProperty, EdgeProperty, VertexProperty }
import org.apache.spark.graphx._

object RandomWalk {

  def randomWalkOneVsAll(graph: Graph[VertexProperty, EdgeProperty], patientID: Long, numIter: Int = 100, alpha: Double = 0.15): List[Long] = {
    /**
     * Given a patient ID, compute the random walk probability w.r.t. to all other patients.
     * Return a List of patient IDs ordered by the highest to the lowest similarity.
     * For ties, random order is okay
     */

    // reference:
    // https://github.com/apache/spark/blob/master/graphx/src/main/scala/org/apache/spark/graphx/lib/PageRank.scala
    var randWalkGraph: Graph[Double, Double] = graph
      .outerJoinVertices(graph.outDegrees)((_, vdata, deg) => deg.getOrElse(0))
      .mapTriplets(t => 1.0 / t.srcAttr, TripletFields.Src)
      .mapVertices((id, _) => if (id == patientID) 1.0 else 0.0)

    var currIter = 0
    var prevRandWalkGraph: Graph[Double, Double] = null
    while (currIter < numIter) {
      currIter += 1
      randWalkGraph.cache()
      prevRandWalkGraph = randWalkGraph

      val probUpdates = randWalkGraph.aggregateMessages[Double](
        ctx => ctx.sendToDst(ctx.srcAttr * ctx.attr), _ + _, TripletFields.Src)

      randWalkGraph = randWalkGraph.outerJoinVertices(probUpdates) {
        (id, oldProb, probSum) => alpha * (if (patientID == id) 1.0 else 0.0) + (1.0 - alpha) * probSum.getOrElse(0.0)
      }.cache()

      randWalkGraph.edges.foreachPartition(x => {})
      prevRandWalkGraph.vertices.unpersist(false)
      prevRandWalkGraph.edges.unpersist(false)

    }
    val patientVertices = graph.vertices
      .filter(v => v._2.isInstanceOf[PatientProperty] && v._1.toLong != patientID)
      .join(randWalkGraph.vertices)

    //     patientVertices.sortBy(v => v._2._2, ascending=false).take(10).foreach(println)
    patientVertices.sortBy(v => v._2._2, ascending = false).take(10).map(v => v._1.toLong).toList
  }
}
