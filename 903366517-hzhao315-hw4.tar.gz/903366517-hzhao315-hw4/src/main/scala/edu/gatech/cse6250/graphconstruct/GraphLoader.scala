/**
 * @author Hang Su <hangsu@gatech.edu>.
 */

package edu.gatech.cse6250.graphconstruct

import edu.gatech.cse6250.model._
import org.apache.spark.graphx._
import org.apache.spark.rdd.RDD

object GraphLoader {
  /**
   * Generate Bipartite Graph using RDDs
   *
   * @input: RDDs for Patient, LabResult, Medication, and Diagnostic
   * @return: Constructed Graph
   *
   */
  def load(patients: RDD[PatientProperty], labResults: RDD[LabResult],
    medications: RDD[Medication], diagnostics: RDD[Diagnostic]): Graph[VertexProperty, EdgeProperty] = {

    /** HINT: See Example of Making Patient Vertices Below */
    val vertexPatient: RDD[(VertexId, VertexProperty)] = patients
      .map(patient => (patient.patientID.toLong, patient.asInstanceOf[VertexProperty]))
    val maxID_tuple = vertexPatient.reduce((x, y) => { if (x._1.toLong < y._1.toLong) y else x })
    val startIndex: Long = maxID_tuple._1.toLong + 1L

    val diagnosticVertexIdRDD = diagnostics.
      map(_.icd9code).
      distinct.
      zipWithIndex.
      map(t => (t._1, t._2 + startIndex))
    val diagnostic2VertexId = diagnosticVertexIdRDD.collect.toMap
    val vertexDiagnostic: RDD[(VertexId, VertexProperty)] = diagnosticVertexIdRDD
      .map(t => (t._2.toLong, DiagnosticProperty(t._1).asInstanceOf[VertexProperty]))

    val startIndex2: Long = startIndex + diagnostic2VertexId.size
    val medicationVertexIdRDD = medications.
      map(_.medicine).
      distinct.
      zipWithIndex.
      map(t => (t._1, t._2 + startIndex2))
    val medicine2VertexId = medicationVertexIdRDD.collect.toMap
    val vertexMedication: RDD[(VertexId, VertexProperty)] = medicationVertexIdRDD
      .map(t => (t._2.toLong, MedicationProperty(t._1).asInstanceOf[VertexProperty]))

    val startIndex3: Long = startIndex2 + medicine2VertexId.size
    val labVertexIdRDD = labResults.
      map(_.labName).
      distinct.
      zipWithIndex.
      map(t => (t._1, t._2 + startIndex3))
    val lab2VertexId = labVertexIdRDD.collect.toMap
    val vertexLab: RDD[(VertexId, VertexProperty)] = labVertexIdRDD
      .map(t => (t._2.toLong, LabResultProperty(t._1).asInstanceOf[VertexProperty]))

    /**
     * HINT: See Example of Making PatientPatient Edges Below
     *
     * This is just sample edges to give you an example.
     * You can remove this PatientPatient edges and make edges you really need
     */
    case class PatientPatientEdgeProperty(someProperty: SampleEdgeProperty) extends EdgeProperty
    val edgePatientPatient: RDD[Edge[EdgeProperty]] = patients
      .map({ p =>
        Edge(p.patientID.toLong, p.patientID.toLong, SampleEdgeProperty("sample").asInstanceOf[EdgeProperty])
      })

    val edgePatientDiagnostic: RDD[Edge[EdgeProperty]] = diagnostics
      .map(event => ((event.patientID, event.icd9code), (event.date.toString.replace("-", "").toLong, event)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, icd9code), (date, event)) => Edge(
          patientID.toLong, // src id
          diagnostic2VertexId(icd9code), // target id
          PatientDiagnosticEdgeProperty(event).asInstanceOf[EdgeProperty])
      }
    val edgeDiagnosticPatient: RDD[Edge[EdgeProperty]] = diagnostics
      .map(event => ((event.patientID, event.icd9code), (event.date.toString.replace("-", "").toLong, event)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, icd9code), (date, event)) => Edge(
          diagnostic2VertexId(icd9code), // src id
          patientID.toLong, // target id
          PatientDiagnosticEdgeProperty(event).asInstanceOf[EdgeProperty])
      }
    val edgePatientLab: RDD[Edge[EdgeProperty]] = labResults
      .map(lab => ((lab.patientID, lab.labName), (lab.date.toString.replace("-", "").toLong, lab)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, labName), (date, lab)) => Edge(
          patientID.toLong, // src id
          lab2VertexId(labName), // target id
          PatientLabEdgeProperty(lab).asInstanceOf[EdgeProperty])
      }
    val edgeLabPatient: RDD[Edge[EdgeProperty]] = labResults
      .map(lab => ((lab.patientID, lab.labName), (lab.date.toString.replace("-", "").toLong, lab)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, labName), (date, lab)) => Edge(
          lab2VertexId(labName), // src id
          patientID.toLong, // target id
          PatientLabEdgeProperty(lab).asInstanceOf[EdgeProperty])
      }
    val edgePatientMedication: RDD[Edge[EdgeProperty]] = medications
      .map(medication => ((medication.patientID, medication.medicine), (medication.date.toString.replace("-", "").toLong, medication)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, medicine), (date, medication)) => Edge(
          patientID.toLong, // src id
          medicine2VertexId(medicine), // target id
          PatientMedicationEdgeProperty(medication).asInstanceOf[EdgeProperty])
      }
    val edgeMedicationPatient: RDD[Edge[EdgeProperty]] = medications
      .map(medication => ((medication.patientID, medication.medicine), (medication.date.toString.replace("-", "").toLong, medication)))
      .reduceByKey { case (x, y) => if (x._1 > y._1) x else y }
      .map {
        case ((patientID, medicine), (date, medication)) => Edge(
          medicine2VertexId(medicine), // src id
          patientID.toLong, // target id
          PatientMedicationEdgeProperty(medication).asInstanceOf[EdgeProperty])
      }

    val vertex = vertexPatient.union(vertexDiagnostic).union(vertexMedication).union(vertexLab)
    val edge = edgePatientDiagnostic.union(edgeDiagnosticPatient)
      .union(edgePatientLab).union(edgeLabPatient)
      .union(edgePatientMedication).union(edgeMedicationPatient)
    // Making Graph
    val graph: Graph[VertexProperty, EdgeProperty] = Graph[VertexProperty, EdgeProperty](vertex, edge)

    //     println(graph.numEdges)
    //     println(graph.numVertices)
    graph
  }
}
